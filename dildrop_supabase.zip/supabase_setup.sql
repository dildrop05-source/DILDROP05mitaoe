-- =============================================
-- DILDROP — Supabase Setup SQL
-- Run this in: Supabase Dashboard → SQL Editor
-- =============================================

-- 1. PRODUCTS TABLE
create table if not exists products (
  id          text primary key,
  name        text not null,
  emoji       text,
  price       int  not null default 80,
  desc        text,
  category    text,
  gradient    text,
  active      boolean default true,
  stock       int default 100,
  image_url   text,
  created_at  timestamptz default now()
);

-- 2. ORDERS TABLE
create table if not exists orders (
  id          text primary key,
  user_id     uuid references auth.users(id),
  customer    jsonb,
  address     jsonb,
  items       jsonb,
  total       int,
  payment     text,
  status      text default 'Pending',
  has_qr      boolean default false,
  timestamp   bigint,
  date        text,
  created_at  timestamptz default now()
);

-- 3. CARTS TABLE (one row per user, overwritten on each update)
create table if not exists carts (
  user_id     uuid primary key references auth.users(id),
  items       jsonb default '[]'::jsonb,
  updated_at  timestamptz default now()
);

-- 4. WISHLISTS TABLE
create table if not exists wishlists (
  user_id     uuid primary key references auth.users(id),
  items       jsonb default '[]'::jsonb,
  updated_at  timestamptz default now()
);

-- ── Row Level Security ───────────────────────────────────────────────

-- Products: anyone can read; only service role can write
alter table products enable row level security;
create policy "Public read products"  on products for select using (true);
create policy "Auth write products"   on products for all using (auth.role() = 'service_role');

-- Orders: users see their own; admin sees all
alter table orders enable row level security;
create policy "Users see own orders"  on orders for select using (auth.uid() = user_id);
create policy "Insert own order"      on orders for insert with check (auth.uid() = user_id or auth.uid() is not null);
create policy "Admin all orders"      on orders for all using (
  (select email from auth.users where id = auth.uid()) = 'sharyushirule615@gmail.com'
);

-- Carts: users manage only their own
alter table carts enable row level security;
create policy "Own cart only"  on carts for all using (auth.uid() = user_id);

-- Wishlists: users manage only their own
alter table wishlists enable row level security;
create policy "Own wishlist only"  on wishlists for all using (auth.uid() = user_id);

-- ── Storage bucket ───────────────────────────────────────────────────
-- Run this separately in Dashboard → Storage → New Bucket:
-- Name: product-images
-- Public: YES (toggle on so image URLs work without auth)
-- Then set this policy on the bucket:
-- Allow all uploads for authenticated users:
-- CREATE POLICY "Auth upload" ON storage.objects FOR INSERT WITH CHECK (auth.role() = 'authenticated');
-- CREATE POLICY "Public read" ON storage.objects FOR SELECT USING (bucket_id = 'product-images');
